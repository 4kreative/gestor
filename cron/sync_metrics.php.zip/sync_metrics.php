<?php
/**
 * GestorPro — Cron de Sincronização de Métricas
 *
 * Configure no cron-job.org para rodar a CADA 1 HORA:
 * GET https://seudominio.com.br/cron/sync_metrics.php?key={CRON_SECRET}
 *
 * Ou via servidor (CLI):
 * 0 * * * * php /caminho/do/projeto/cron/sync_metrics.php
 */

// ── Carrega config ANTES de checar a chave ────────────────────────────────────
define('CLI_MODE', true);
require_once __DIR__.'/../config/config.php';

// Suporte HTTP (cron-job.org) e CLI
$isCli = (PHP_SAPI === 'cli');
if (!$isCli) {
    $key = $_SERVER['HTTP_X_CRON_KEY'] ?? ($_GET['key'] ?? '');
    if ($key !== CRON_SECRET) {
        http_response_code(403);
        die(json_encode(['error' => 'Unauthorized']));
    }
    header('Content-Type: application/json');
}

set_exception_handler(function(Throwable $e) use ($isCli) {
    $msg = $e->getMessage() . ' em ' . basename($e->getFile()) . ':' . $e->getLine();
    if ($isCli) echo "[ERRO] $msg\n";
    else echo json_encode(['success' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
});

require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/../core/helpers.php';
require_once __DIR__.'/../controllers/AccountController.php';

$now = new DateTime('now', new DateTimeZone(APP_TIMEZONE));
$log = [];
$ok  = 0;
$err = 0;

$log[] = "[" . $now->format('Y-m-d H:i:s') . "] Iniciando sincronização de métricas...";

$db   = Database::getInstance();
$accs = $db->query("SELECT * FROM ad_accounts WHERE status='active'")->fetchAll();
$log[] = "Contas ativas: " . count($accs);

foreach ($accs as $acc) {
    try {
        $ctrl  = new AccountController();
        $start = date('Y-m-d', strtotime('-30 days'));
        $end   = date('Y-m-d');

        if ($acc['platform'] === 'meta') {
            $method = new ReflectionMethod($ctrl, 'syncMeta');
            $method->setAccessible(true);
            $method->invoke($ctrl, $acc, $start, $end, $db);
        } else {
            $method = new ReflectionMethod($ctrl, 'syncGoogle');
            $method->setAccessible(true);
            $method->invoke($ctrl, $acc, $start, $end, $db);
        }

        $log[] = "[OK] Conta #{$acc['id']} — {$acc['account_name']} ({$acc['platform']})";

        // Notificação de sucesso (1x por dia por conta)
        try {
            $hoje = $now->format('Y-m-d');
            $jaNotificou = $db->query(
                "SELECT id FROM notifications WHERE user_id=? AND type='success'
                 AND title=? AND DATE(created_at)=? LIMIT 1",
                [$acc['user_id'], "📊 Métricas sincronizadas: {$acc['account_name']}", $hoje]
            )->fetch();
            if (!$jaNotificou) {
                $db->query(
                    "INSERT INTO notifications (user_id, type, title, body) VALUES (?, 'success', ?, ?)",
                    [
                        $acc['user_id'],
                        "📊 Métricas sincronizadas: {$acc['account_name']}",
                        "Dados dos últimos 30 dias atualizados com sucesso em " . $now->format('H:i') . ".",
                    ]
                );
            }
        } catch (\Throwable $_e) {}

        $ok++;
    } catch (\Exception $e) {
        $log[] = "[ERRO] Conta #{$acc['id']} {$acc['account_name']}: " . $e->getMessage();

        // Notificação de erro
        try {
            $db->query(
                "INSERT INTO notifications (user_id, type, title, body) VALUES (?, 'error', ?, ?)",
                [
                    $acc['user_id'],
                    "❌ Falha ao sincronizar: {$acc['account_name']}",
                    mb_substr($e->getMessage(), 0, 200),
                ]
            );
        } catch (\Throwable $_e) {}

        $err++;
    }
}

$log[] = "[" . date('Y-m-d H:i:s') . "] Concluído. OK: $ok | Erros: $err";

if ($isCli) {
    foreach ($log as $linha) echo $linha . "\n";
} else {
    echo json_encode([
        'success' => true,
        'hora'    => $now->format('H:i'),
        'ok'      => $ok,
        'erros'   => $err,
        'log'     => $log,
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
